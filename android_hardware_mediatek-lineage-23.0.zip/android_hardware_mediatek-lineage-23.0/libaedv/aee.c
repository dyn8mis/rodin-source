int aee_switch_ftrace() {
    return 0;
}

int aee_system_exception() {
    return 0;
}

int aee_system_warning() {
    return 0;
}

int aee_modem_warning() {
    return 0;
}
