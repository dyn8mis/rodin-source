# Common hardware components for MediaTek devices
