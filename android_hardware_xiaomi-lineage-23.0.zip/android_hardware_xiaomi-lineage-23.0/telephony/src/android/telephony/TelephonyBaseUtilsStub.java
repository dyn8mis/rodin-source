/*
 * SPDX-FileCopyrightText: 2024 The LineageOS Project
 * SPDX-License-Identifier: Apache-2.0
 */

package android.telephony;

public class TelephonyBaseUtilsStub {
    public static boolean isMiuiRom() {
        return false;
    }
}
