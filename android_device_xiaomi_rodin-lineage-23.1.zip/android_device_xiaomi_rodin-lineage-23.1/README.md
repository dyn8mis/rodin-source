# Android device tree for POCO X7 Pro / Redmi Turbo 4 (rodin)

```
#
# Copyright (C) 2025 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#
```
