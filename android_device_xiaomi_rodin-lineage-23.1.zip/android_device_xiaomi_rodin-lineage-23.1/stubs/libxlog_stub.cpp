extern "C" {
 void _Z33send_record_playback_fail_to_xlogii() {}
 void _Z36send_voice_call_or_voip_data_to_xlog12audio_mode_tPc() {}
 void _Z38send_EarsCompensation_dailyuse_to_xlog20audio_output_flags_t12audio_mode_tRKNSt3__16vectorI15audio_devices_tNS1_9allocatorIS3_EEEE() {}
 void _Z29send_misound_dailyuse_to_xlog20audio_output_flags_tRKNSt3__16vectorI15audio_devices_tNS0_9allocatorIS2_EEEE() {}
 void _Z31send_music_or_game_data_to_xlogiRKNSt3__16vectorI15audio_devices_tNS_9allocatorIS1_EEEEb() {}
 void _Z27send_game_voip_data_to_xlogi() {}
 void _Z32send_sound_recorder_data_to_xlogRNSt3__16vectorI15audio_devices_tNS_9allocatorIS1_EEEE() {}
 void _Z24send_haptic_data_to_xlogv() {}
 void xlog_send() {}
 void xlog_send_int() {}
}
