/*
 * Copyright (C) 2023-2024 The LineageOS Project
 *
 * SPDX-License-Identifier: Apache-2.0
 */

void _ZN7android18BnProducerListener16onBufferDetachedEi(int slot) {
   (void)slot;
}
